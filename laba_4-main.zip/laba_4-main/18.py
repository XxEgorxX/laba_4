class Employee:
    def __init__(self, name, salary, age):
        self.__name = name      
        self.__salary = salary  

