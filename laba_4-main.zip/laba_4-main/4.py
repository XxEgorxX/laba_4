#4
class User():
user1 = User()
user2 = User()
user1.name = 'Oleg'
user2.name = 'Maksim'
print(user1.name)
print(user2.name)

class Employee():
employee1 = Employee()
employee2 = Employee()
employee1.name = 'savanna'
employee1.salary = 52000
employee2.name = 'phil'
employee2.salary = 48000
print(employee1.name)
print(employee1.salary)
print(employee2.name)
print(employee2.salary)