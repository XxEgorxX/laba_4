#2
class User:
    pass
user = User()
print(user)

class Employee:
    pass
employee = Employee()
print(employee)