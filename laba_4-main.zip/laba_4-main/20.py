# 1 False
# 2 True
# 3 False
# 4 False
# 5 False