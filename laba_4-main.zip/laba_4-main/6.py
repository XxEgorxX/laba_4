class User:
    def show(name, surname):
        return name + ' ' + surname 
        user = User()
        print(user.show('oleg', 'smirnov'))

class Employee:
    def sal(name, salary):
        return sal + ' ' + salary
        employee = Employee()
        print(employee.sal('oleg', '400$'))