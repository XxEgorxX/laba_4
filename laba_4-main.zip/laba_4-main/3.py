class User():
    pass
user = User()
user.name = 'john' 
user.surname = 'smit'
print(user.name)
print(user.surname)

class Employee:
    pass
employee = Employee()
employee.name = 'Oleg'
employee.age = 30
employee.salary = 5000000
print(employee.name)
print(employee.age)
print(employee.salary)