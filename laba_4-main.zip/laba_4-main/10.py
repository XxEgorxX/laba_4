class Employee:
    def __init__(self, name, surname):
        self.name = name
        self.surname = surname

employee = Employee("Alex", "Smith")
print(employee.name)  
print(employee.surname) 
