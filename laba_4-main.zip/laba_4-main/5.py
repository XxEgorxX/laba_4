#5
class User:
 def show():
  return '+++'
user = User() 
print(user.show()) 

class Employee:
    def chr():
    return '---'
employee = Employee()
print(employee.chr())
