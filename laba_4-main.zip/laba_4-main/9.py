class Student:
    name = "Anna"
    surname = "Petrova"

student = Student()
print(student.name)    # 'Anna'
print(student.surname) # 'Petrova'
